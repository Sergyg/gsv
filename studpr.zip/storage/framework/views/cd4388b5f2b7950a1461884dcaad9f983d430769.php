<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tytuł – Zadanie zdalne e-MSI</title>
    <link rel="stylesheet" href="./css/base.css">
    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" href="./css/normalize.css">
    <link rel="stylesheet" href="./css/reset.css">
</head>

<body>
<div class="section h4 row">
    <div class="sidebar col" id="Lewy">
        <ul class="h4">
            <a href="kontrolki.blade.php"><li class="liMargin">a. Różne kontrolki HTML</li></a>
            <a href="Pracovniki.blade.php"><li class="liMargin">b. Tabela Pracowników</li></a>
            <a href="faktury.blade.php"><li class="liMargin">c. Tabela Faktur VAT</li></a>
            <a href="delehacji.blade.php"><li class="liMargin">d. Tabela Delegacji BD</li></a>
            <a href="kontrahenty.blade.php"><li class="liMargin">e. Dane Kontrahentów</li></a>
        </ul>
    </div>
    <div class="table col" id="Prawy">

    </div>

</div>
</body>
</html>


<?php /**PATH C:\OpenServer\domains\laravelvue\Tablebase\studpr\resources\views/home.blade.php ENDPATH**/ ?>