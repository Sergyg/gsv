<?php return array (
  'kontrahenty' => 'App\\Http\\Livewire\\Kontrahenty',
  'kontrahenty-component' => 'App\\Http\\Livewire\\KontrahentyComponent',
  'layouts.base' => 'App\\Http\\Livewire\\Layouts\\Base',
);